def DevGAG():
    print("This is DevGAG!")
    
    
    
    
    
DevGAG()

